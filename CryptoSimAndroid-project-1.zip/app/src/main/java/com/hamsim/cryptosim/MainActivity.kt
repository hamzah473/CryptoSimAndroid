package com.hamsim.cryptosim

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.max

private const val START_CASH = 10_000_000_000_000.0
private val client = OkHttpClient()

data class Coin(val symbol: String, val price: Double, val change: Double)
data class Holding(val symbol: String, var qty: Double, var avg: Double)
data class Position(val symbol: String, val side: String, val margin: Double, val leverage: Double,
                    val entry: Double, val qty: Double, var mark: Double)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { CryptoSimApp() } }
    }
}

@Composable
private fun CryptoSimApp() {
    var cash by remember { mutableDoubleStateOf(START_CASH) }
    val holdings = remember { mutableStateListOf<Holding>() }
    val positions = remember { mutableStateListOf<Position>() }
    val trades = remember { mutableStateListOf<String>() }
    var coins by remember { mutableStateOf<List<Coin>>(emptyList()) }
    var status by remember { mutableStateOf("Mengambil harga Binance…") }
    var selected by remember { mutableStateOf("BTCUSDT") }
    var amount by remember { mutableStateOf("1000") }
    var leverage by remember { mutableStateOf("5") }
    var screen by remember { mutableStateOf("Pasar") }
    var refresh by remember { mutableIntStateOf(0) }

    LaunchedEffect(refresh) {
        while (true) {
            try {
                val result = withContext(Dispatchers.IO) {
                    val req = Request.Builder()
                        .url("https://data-api.binance.vision/api/v3/ticker/24hr")
                        .header("User-Agent", "CryptoSimAndroid/1.0")
                        .build()
                    client.newCall(req).execute().use { response ->
                        if (!response.isSuccessful) error("HTTP ${response.code}")
                        JSONArray(response.body?.string() ?: "[]")
                    }
                }
                val wanted = listOf("BTCUSDT", "ETHUSDT", "BNBUSDT", "SOLUSDT", "XRPUSDT",
                    "DOGEUSDT", "ADAUSDT", "LINKUSDT", "LTCUSDT", "BCHUSDT", "AVAXUSDT",
                    "DOTUSDT", "NEARUSDT", "ATOMUSDT", "ETCUSDT", "TRXUSDT", "SUIUSDT",
                    "SEIUSDT", "FETUSDT", "INJUSDT", "KASUSDT")
                val map = mutableMapOf<String, Coin>()
                for (i in 0 until result.length()) {
                    val o = result.getJSONObject(i)
                    val s = o.optString("symbol")
                    if (s in wanted) map[s] = Coin(s, o.optString("lastPrice").toDoubleOrNull() ?: 0.0,
                        o.optString("priceChangePercent").toDoubleOrNull() ?: 0.0)
                }
                coins = wanted.mapNotNull { map[it] }.sortedBy { it.symbol }
                positions.forEach { p -> p.mark = coins.firstOrNull { it.symbol == p.symbol }?.price ?: p.mark }
                status = "Harga Binance • diperbarui otomatis tiap 15 detik"
            } catch (e: Exception) {
                status = "Harga gagal dimuat: ${e.message ?: "cek internet"}"
            }
            delay(15_000)
        }
    }

    val money = remember { NumberFormat.getCurrencyInstance(Locale.US) }
    fun price(symbol: String) = coins.firstOrNull { it.symbol == symbol }?.price ?: 0.0
    fun fmt(v: Double) = if (v.isFinite()) money.format(v) else "—"
    fun qtyFmt(v: Double) = String.format(Locale.US, "%.8f", v).trimEnd('0').trimEnd('.')
    fun buySpot(symbol: String, usd: Double) {
        val p = price(symbol)
        if (p <= 0 || usd <= 0 || usd > cash) { trades.add("GAGAL beli $symbol: saldo/harga tidak cukup"); return }
        val q = usd / p
        val h = holdings.firstOrNull { it.symbol == symbol }
        if (h == null) holdings.add(Holding(symbol, q, p))
        else { h.avg = ((h.qty * h.avg) + usd) / (h.qty + q); h.qty += q }
        cash -= usd
        trades.add("BELI $symbol ${qtyFmt(q)} @ ${fmt(p)} • ${fmt(usd)}")
    }
    fun sellSpot(symbol: String, usd: Double) {
        val p = price(symbol)
        val h = holdings.firstOrNull { it.symbol == symbol }
        if (p <= 0 || usd <= 0 || h == null || h.qty <= 0) { trades.add("GAGAL jual $symbol: tidak ada aset"); return }
        val q = minOf(h.qty, usd / p)
        val proceeds = q * p
        h.qty -= q
        cash += proceeds
        trades.add("JUAL $symbol ${qtyFmt(q)} @ ${fmt(p)} • +${fmt(proceeds)}")
        if (h.qty < 1e-12) holdings.remove(h)
    }
    fun openPosition(symbol: String, side: String, margin: Double, lev: Double) {
        val p = price(symbol)
        if (p <= 0 || margin <= 0 || lev !in 1.0..50.0 || margin > cash) {
            trades.add("GAGAL futures: periksa margin, harga, dan leverage (1–50x)"); return
        }
        val notional = margin * lev
        val q = notional / p
        cash -= margin
        positions.add(Position(symbol, side, margin, lev, p, q, p))
        trades.add("FUTURES $side $symbol ${lev}x • margin ${fmt(margin)} • entry ${fmt(p)}")
    }

    Scaffold(topBar = {
        TopAppBarCompat(title = "CryptoSim • Paper Trading", status = status)
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Pasar", "Spot", "Futures", "Portofolio", "Riwayat").forEach { tab ->
                    FilterChip(selected = screen == tab, onClick = { screen = tab }, label = { Text(tab) })
                }
            }
            when (screen) {
                "Pasar" -> LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                    item { Text("Harga pasar nyata • USD", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)) }
                    items(coins) { c ->
                        Card(Modifier.fillMaxWidth().padding(bottom = 6.dp), onClick = { selected = c.symbol }) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column { Text(c.symbol, fontWeight = FontWeight.Bold); Text(if (selected == c.symbol) "Dipilih" else "Ketuk untuk pilih", style = MaterialTheme.typography.bodySmall) }
                                Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                    Text(fmt(c.price), fontWeight = FontWeight.SemiBold)
                                    Text(String.format(Locale.US, "%+.2f%%", c.change), color = if (c.change >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
                "Spot" -> LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                    item {
                        Text("Trading Spot simulasi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Saldo tersedia: ${fmt(cash)}")
                        Spacer(Modifier.height(12.dp))
                        Text("Aset: $selected • Harga: ${fmt(price(selected))}")
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(selected, { selected = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(20) }, label = { Text("Simbol Binance, contoh BTCUSDT") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(amount, { amount = it }, label = { Text("Nilai transaksi (USD)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { buySpot(selected, amount.toDoubleOrNull() ?: 0.0) }) { Text("Beli") }
                            OutlinedButton(onClick = { sellSpot(selected, amount.toDoubleOrNull() ?: 0.0) }) { Text("Jual senilai USD") }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text("Jual mengubah nilai USD menjadi jumlah koin pada harga terbaru. Tidak ada order sungguhan.", style = MaterialTheme.typography.bodySmall)
                    }
                }
                "Futures" -> LazyColumn(Modifier.fillMaxSize().padding(16.dp)) {
                    item {
                        Text("Futures simulasi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Saldo tersedia: ${fmt(cash)}")
                        Text("Harga mark: ${fmt(price(selected))}")
                        OutlinedTextField(selected, { selected = it.uppercase().filter { ch -> ch.isLetterOrDigit() }.take(20) }, label = { Text("Simbol, contoh BTCUSDT") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        OutlinedTextField(amount, { amount = it }, label = { Text("Margin (USD)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(leverage, { leverage = it }, label = { Text("Leverage 1–50x") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { openPosition(selected, "LONG", amount.toDoubleOrNull() ?: 0.0, leverage.toDoubleOrNull() ?: 0.0) }) { Text("Long") }
                            OutlinedButton(onClick = { openPosition(selected, "SHORT", amount.toDoubleOrNull() ?: 0.0, leverage.toDoubleOrNull() ?: 0.0) }) { Text("Short") }
                        }
                        Text("Estimasi edukasi: isolated margin, maintenance margin 0,5%; bukan rumus likuidasi Binance.", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(12.dp))
                    }
                    items(positions.toList()) { p ->
                        val pnl = (p.mark - p.entry) * p.qty * if (p.side == "LONG") 1 else -1
                        val liq = if (p.side == "LONG") p.entry * (1 - 1 / p.leverage + 0.005) else p.entry * (1 + 1 / p.leverage - 0.005)
                        val liquidated = if (p.side == "LONG") p.mark <= liq else p.mark >= liq
                        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text("${p.side} ${p.symbol} • ${p.leverage}x", fontWeight = FontWeight.Bold)
                                Text("Entry ${fmt(p.entry)} • Mark ${fmt(p.mark)}")
                                Text("PnL belum terealisasi: ${fmt(pnl)}")
                                Text("Estimasi harga likuidasi: ${fmt(liq)}")
                                if (liquidated) Text("PERINGATAN: ambang likuidasi simulasi terlewati", color = MaterialTheme.colorScheme.error)
                                TextButton(onClick = {
                                    val equity = max(0.0, p.margin + pnl)
                                    cash += equity
                                    positions.remove(p)
                                    trades.add("TUTUP ${p.side} ${p.symbol} • hasil margin+PnL ${fmt(equity)}")
                                }) { Text("Tutup posisi") }
                            }
                        }
                    }
                }
                "Portofolio" -> LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
                    item {
                        Text("Portofolio", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Kas USD: ${fmt(cash)}")
                        Text("Nilai spot: ${fmt(holdings.sumOf { it.qty * price(it.symbol) })}")
                        Text("Ekuitas futures (perkiraan): ${fmt(positions.sumOf { it.margin + (it.mark - it.entry) * it.qty * if (it.side == "LONG") 1 else -1 })}")
                        Spacer(Modifier.height(12.dp))
                        Text("Aset spot", fontWeight = FontWeight.Bold)
                    }
                    items(holdings.toList()) { h -> Text("${h.symbol}: ${qtyFmt(h.qty)} • nilai ${fmt(h.qty * price(h.symbol))} • rata-rata ${fmt(h.avg)}", Modifier.padding(vertical = 5.dp)) }
                }
                else -> LazyColumn(Modifier.fillMaxSize().padding(12.dp)) {
                    item { Text("Riwayat transaksi", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)) }
                    items(trades.reversed()) { t -> Text(t, Modifier.padding(vertical = 6.dp)); HorizontalDivider() }
                    item { Spacer(Modifier.height(12.dp)); OutlinedButton(onClick = { trades.clear() }) { Text("Hapus riwayat") } }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TopAppBarCompat(title: String, status: String) {
    Column {
        TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) })
        Text(status, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall)
    }
}
